import os

os.system('app.py')

